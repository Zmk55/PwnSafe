#!/bin/bash
echo "Starting PwnSafe..."
./PwnSafe
