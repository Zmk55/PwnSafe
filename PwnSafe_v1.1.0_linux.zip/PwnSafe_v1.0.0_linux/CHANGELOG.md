# Changelog

## [1.0.0] - 2025-02-08
### Added
- Initial release of PwnSafe with backup and restore functionality.